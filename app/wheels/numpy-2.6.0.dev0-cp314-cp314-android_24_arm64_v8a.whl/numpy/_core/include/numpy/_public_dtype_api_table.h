/* Generated from numpy_api.multiarray_dtype_api. */
#ifndef NUMPY_CORE_INCLUDE_NUMPY__PUBLIC_DTYPE_API_TABLE_H_
#define NUMPY_CORE_INCLUDE_NUMPY__PUBLIC_DTYPE_API_TABLE_H_

#if !(defined(NPY_INTERNAL_BUILD) && NPY_INTERNAL_BUILD)

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArrayDTypeMeta_Type (*(PyTypeObject *)PyArray_API[320])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_BoolDType (*(PyArray_DTypeMeta *)PyArray_API[321])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ByteDType (*(PyArray_DTypeMeta *)PyArray_API[322])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UByteDType (*(PyArray_DTypeMeta *)PyArray_API[323])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ShortDType (*(PyArray_DTypeMeta *)PyArray_API[324])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UShortDType (*(PyArray_DTypeMeta *)PyArray_API[325])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_IntDType (*(PyArray_DTypeMeta *)PyArray_API[326])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UIntDType (*(PyArray_DTypeMeta *)PyArray_API[327])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_LongDType (*(PyArray_DTypeMeta *)PyArray_API[328])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ULongDType (*(PyArray_DTypeMeta *)PyArray_API[329])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_LongLongDType (*(PyArray_DTypeMeta *)PyArray_API[330])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ULongLongDType (*(PyArray_DTypeMeta *)PyArray_API[331])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_Int8DType (*(PyArray_DTypeMeta *)PyArray_API[332])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UInt8DType (*(PyArray_DTypeMeta *)PyArray_API[333])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_Int16DType (*(PyArray_DTypeMeta *)PyArray_API[334])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UInt16DType (*(PyArray_DTypeMeta *)PyArray_API[335])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_Int32DType (*(PyArray_DTypeMeta *)PyArray_API[336])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UInt32DType (*(PyArray_DTypeMeta *)PyArray_API[337])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_Int64DType (*(PyArray_DTypeMeta *)PyArray_API[338])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UInt64DType (*(PyArray_DTypeMeta *)PyArray_API[339])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_IntpDType (*(PyArray_DTypeMeta *)PyArray_API[340])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UIntpDType (*(PyArray_DTypeMeta *)PyArray_API[341])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_HalfDType (*(PyArray_DTypeMeta *)PyArray_API[342])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_FloatDType (*(PyArray_DTypeMeta *)PyArray_API[343])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_DoubleDType (*(PyArray_DTypeMeta *)PyArray_API[344])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_LongDoubleDType (*(PyArray_DTypeMeta *)PyArray_API[345])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_CFloatDType (*(PyArray_DTypeMeta *)PyArray_API[346])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_CDoubleDType (*(PyArray_DTypeMeta *)PyArray_API[347])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_CLongDoubleDType (*(PyArray_DTypeMeta *)PyArray_API[348])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_BytesDType (*(PyArray_DTypeMeta *)PyArray_API[349])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_UnicodeDType (*(PyArray_DTypeMeta *)PyArray_API[350])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_DatetimeDType (*(PyArray_DTypeMeta *)PyArray_API[351])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_TimedeltaDType (*(PyArray_DTypeMeta *)PyArray_API[352])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ObjectDType (*(PyArray_DTypeMeta *)PyArray_API[353])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_VoidDType (*(PyArray_DTypeMeta *)PyArray_API[354])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_PyLongDType (*(PyArray_DTypeMeta *)PyArray_API[355])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_PyFloatDType (*(PyArray_DTypeMeta *)PyArray_API[356])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_PyComplexDType (*(PyArray_DTypeMeta *)PyArray_API[357])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_DefaultIntDType (*(PyArray_DTypeMeta *)PyArray_API[358])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_StringDType (*(PyArray_DTypeMeta *)PyArray_API[359])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_IntAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[366])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_FloatAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[367])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_0_API_VERSION
#define PyArray_ComplexAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[368])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_6_API_VERSION
#define PyArray_NumberAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[379])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_6_API_VERSION
#define PyArray_SignedIntegerAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[380])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_6_API_VERSION
#define PyArray_UnsignedIntegerAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[381])
#endif

#if NPY_FEATURE_VERSION >= NPY_2_6_API_VERSION
#define PyArray_InexactAbstractDType (*(PyArray_DTypeMeta *)PyArray_API[382])
#endif
#endif

#endif
