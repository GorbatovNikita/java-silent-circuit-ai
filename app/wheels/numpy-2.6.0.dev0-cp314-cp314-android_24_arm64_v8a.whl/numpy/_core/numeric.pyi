import numbers
from _typeshed import Incomplete
from builtins import bool as py_bool
from collections.abc import Callable, Iterable, Sequence
from typing import (
    Any,
    Literal as L,
    Never,
    SupportsAbs,
    SupportsIndex,
    TypeVar,
    overload,
)
from typing_extensions import TypeIs, deprecated

import numpy as np
from numpy import (
    False_,
    True_,
    _OrderCF,
    _OrderKACF,
    bitwise_not,
    inf,
    little_endian,
    nan,
    newaxis,
    ufunc,
)
from numpy._typing import (
    Array0D,
    Array1D,
    Array2D,
    Array3D,
    Array4D,
    ArrayLike,
    DTypeLike,
    NDArray,
    _AnyShape,
    _ArrayLike,
    _ArrayLikeBool_co,
    _ArrayLikeComplex_co,
    _ArrayLikeFloat_co,
    _ArrayLikeInt_co,
    _ArrayLikeNumber_co,
    _ArrayLikeTD64_co,
    _Complex128Codes,
    _DTypeLike,
    _DTypeLikeBool,
    _Float64Codes,
    _IntPCodes,
    _NestedSequence,
    _NumberLike_co,
    _ScalarLike_co,
    _Shape,
    _ShapeLike,
    _SupportsArray,
    _SupportsArrayFunc,
    _SupportsDType,
)

from ._asarray import require
from ._ufunc_config import (
    errstate,
    getbufsize,
    geterr,
    geterrcall,
    setbufsize,
    seterr,
    seterrcall,
)
from .arrayprint import (
    array2string,
    array_repr,
    array_str,
    format_float_positional,
    format_float_scientific,
    get_printoptions,
    printoptions,
    set_printoptions,
)
from .fromnumeric import (
    all,
    amax,
    amin,
    any,
    argmax,
    argmin,
    argpartition,
    argsort,
    around,
    choose,
    clip,
    compress,
    cumprod,
    cumsum,
    cumulative_prod,
    cumulative_sum,
    diagonal,
    matrix_transpose,
    max,
    mean,
    min,
    minmax,
    ndim,
    nonzero,
    partition,
    prod,
    ptp,
    put,
    ravel,
    repeat,
    reshape,
    resize,
    round,
    searchsorted,
    shape,
    size,
    sort,
    squeeze,
    std,
    sum,
    swapaxes,
    take,
    top_k,
    trace,
    transpose,
    var,
)
from .multiarray import (
    ALLOW_THREADS as ALLOW_THREADS,
    BUFSIZE as BUFSIZE,
    CLIP as CLIP,
    MAXDIMS as MAXDIMS,
    MAY_SHARE_BOUNDS as MAY_SHARE_BOUNDS,
    MAY_SHARE_EXACT as MAY_SHARE_EXACT,
    RAISE as RAISE,
    WRAP as WRAP,
    _Array,
    arange,
    array,
    asanyarray,
    asarray,
    ascontiguousarray,
    asfortranarray,
    broadcast,
    can_cast,
    concatenate,
    copyto,
    dot,
    dtype,
    empty,
    empty_like,
    flatiter,
    from_dlpack,
    frombuffer,
    fromfile,
    fromiter,
    fromstring,
    inner,
    lexsort,
    matmul,
    may_share_memory,
    min_scalar_type,
    ndarray,
    nditer,
    nested_iters,
    normalize_axis_index as normalize_axis_index,
    promote_types,
    putmask,
    result_type,
    shares_memory,
    vdot,
    where,
    zeros,
)
from .numerictypes import (
    ScalarType,
    bool,
    bool_,
    busday_count,
    busday_offset,
    busdaycalendar,
    byte,
    bytes_,
    cdouble,
    character,
    clongdouble,
    complex64,
    complex128,
    complex192,
    complex256,
    complexfloating,
    csingle,
    datetime64,
    datetime_as_string,
    datetime_data,
    double,
    flexible,
    float16,
    float32,
    float64,
    float96,
    float128,
    floating,
    generic,
    half,
    inexact,
    int8,
    int16,
    int32,
    int64,
    int_,
    intc,
    integer,
    intp,
    is_busday,
    isdtype,
    issubdtype,
    long,
    longdouble,
    longlong,
    number,
    object_,
    short,
    signedinteger,
    single,
    str_,
    timedelta64,
    typecodes,
    ubyte,
    uint,
    uint8,
    uint16,
    uint32,
    uint64,
    uintc,
    uintp,
    ulong,
    ulonglong,
    unsignedinteger,
    ushort,
    void,
)
from .umath import (
    absolute,
    add,
    arccos,
    arccosh,
    arcsin,
    arcsinh,
    arctan,
    arctan2,
    arctanh,
    bitwise_and,
    bitwise_count,
    bitwise_or,
    bitwise_xor,
    cbrt,
    ceil,
    conj,
    conjugate,
    copysign,
    cos,
    cosh,
    deg2rad,
    degrees,
    divide,
    divmod,
    e,
    equal,
    euler_gamma,
    exp,
    exp2,
    expm1,
    fabs,
    float_power,
    floor,
    floor_divide,
    fmax,
    fmin,
    fmod,
    frexp,
    frompyfunc,
    gcd,
    greater,
    greater_equal,
    heaviside,
    hypot,
    invert,
    isfinite,
    isinf,
    isnan,
    isnat,
    lcm,
    ldexp,
    left_shift,
    less,
    less_equal,
    log,
    log1p,
    log2,
    log10,
    logaddexp,
    logaddexp2,
    logical_and,
    logical_not,
    logical_or,
    logical_xor,
    matvec,
    maximum,
    minimum,
    mod,
    modf,
    multiply,
    negative,
    nextafter,
    not_equal,
    pi,
    positive,
    power,
    rad2deg,
    radians,
    reciprocal,
    remainder,
    right_shift,
    rint,
    sign,
    signbit,
    sin,
    sinh,
    spacing,
    sqrt,
    square,
    subtract,
    tan,
    tanh,
    true_divide,
    trunc,
    vecdot,
    vecmat,
)

__all__ = [
    "False_",
    "ScalarType",
    "True_",
    "absolute",
    "add",
    "all",
    "allclose",
    "amax",
    "amin",
    "any",
    "arange",
    "arccos",
    "arccosh",
    "arcsin",
    "arcsinh",
    "arctan",
    "arctan2",
    "arctanh",
    "argmax",
    "argmin",
    "argpartition",
    "argsort",
    "argwhere",
    "around",
    "array",
    "array2string",
    "array_equal",
    "array_equiv",
    "array_repr",
    "array_str",
    "asanyarray",
    "asarray",
    "ascontiguousarray",
    "asfortranarray",
    "astype",
    "base_repr",
    "binary_repr",
    "bitwise_and",
    "bitwise_count",
    "bitwise_not",
    "bitwise_or",
    "bitwise_xor",
    "bool",
    "bool_",
    "broadcast",
    "busday_count",
    "busday_offset",
    "busdaycalendar",
    "byte",
    "bytes_",
    "can_cast",
    "cbrt",
    "cdouble",
    "ceil",
    "character",
    "choose",
    "clip",
    "clongdouble",
    "complex64",
    "complex128",
    "complex192",
    "complex256",
    "complexfloating",
    "compress",
    "concatenate",
    "conj",
    "conjugate",
    "convolve",
    "copysign",
    "copyto",
    "correlate",
    "cos",
    "cosh",
    "count_nonzero",
    "cross",
    "csingle",
    "cumprod",
    "cumsum",
    "cumulative_prod",
    "cumulative_sum",
    "datetime64",
    "datetime_as_string",
    "datetime_data",
    "deg2rad",
    "degrees",
    "diagonal",
    "divide",
    "divmod",
    "dot",
    "double",
    "dtype",
    "e",
    "empty",
    "empty_like",
    "equal",
    "errstate",
    "euler_gamma",
    "exp",
    "exp2",
    "expm1",
    "fabs",
    "flatiter",
    "flatnonzero",
    "flexible",
    "float16",
    "float32",
    "float64",
    "float96",
    "float128",
    "float_power",
    "floating",
    "floor",
    "floor_divide",
    "fmax",
    "fmin",
    "fmod",
    "format_float_positional",
    "format_float_scientific",
    "frexp",
    "from_dlpack",
    "frombuffer",
    "fromfile",
    "fromfunction",
    "fromiter",
    "frompyfunc",
    "fromstring",
    "full",
    "full_like",
    "gcd",
    "generic",
    "get_printoptions",
    "getbufsize",
    "geterr",
    "geterrcall",
    "greater",
    "greater_equal",
    "half",
    "heaviside",
    "hypot",
    "identity",
    "indices",
    "inexact",
    "inf",
    "inner",
    "int8",
    "int16",
    "int32",
    "int64",
    "int_",
    "intc",
    "integer",
    "intp",
    "invert",
    "is_busday",
    "isclose",
    "isdtype",
    "isfinite",
    "isfortran",
    "isinf",
    "isnan",
    "isnat",
    "isscalar",
    "issubdtype",
    "lcm",
    "ldexp",
    "left_shift",
    "less",
    "less_equal",
    "lexsort",
    "little_endian",
    "log",
    "log1p",
    "log2",
    "log10",
    "logaddexp",
    "logaddexp2",
    "logical_and",
    "logical_not",
    "logical_or",
    "logical_xor",
    "long",
    "longdouble",
    "longlong",
    "matmul",
    "matrix_transpose",
    "matvec",
    "max",
    "maximum",
    "may_share_memory",
    "mean",
    "min",
    "min_scalar_type",
    "minimum",
    "minmax",
    "mod",
    "modf",
    "moveaxis",
    "multiply",
    "nan",
    "ndarray",
    "ndim",
    "nditer",
    "negative",
    "nested_iters",
    "newaxis",
    "nextafter",
    "nonzero",
    "not_equal",
    "number",
    "object_",
    "ones",
    "ones_like",
    "outer",
    "partition",
    "pi",
    "positive",
    "power",
    "printoptions",
    "prod",
    "promote_types",
    "ptp",
    "put",
    "putmask",
    "rad2deg",
    "radians",
    "ravel",
    "reciprocal",
    "remainder",
    "repeat",
    "require",
    "reshape",
    "resize",
    "result_type",
    "right_shift",
    "rint",
    "roll",
    "rollaxis",
    "round",
    "searchsorted",
    "set_printoptions",
    "setbufsize",
    "seterr",
    "seterrcall",
    "shape",
    "shares_memory",
    "short",
    "sign",
    "signbit",
    "signedinteger",
    "sin",
    "single",
    "sinh",
    "size",
    "sort",
    "spacing",
    "sqrt",
    "square",
    "squeeze",
    "std",
    "str_",
    "subtract",
    "sum",
    "swapaxes",
    "take",
    "tan",
    "tanh",
    "tensordot",
    "timedelta64",
    "top_k",
    "trace",
    "transpose",
    "true_divide",
    "trunc",
    "typecodes",
    "ubyte",
    "ufunc",
    "uint",
    "uint8",
    "uint16",
    "uint32",
    "uint64",
    "uintc",
    "uintp",
    "ulong",
    "ulonglong",
    "unsignedinteger",
    "ushort",
    "var",
    "vdot",
    "vecdot",
    "vecmat",
    "void",
    "where",
    "zeros",
    "zeros_like",
]

_AnyNumberT = TypeVar(
    "_AnyNumberT",
    np.int8, np.int16, np.int32, np.int64,
    np.uint8, np.uint16, np.uint32, np.uint64,
    np.float16, np.float32, np.float64, np.longdouble,
    np.complex64, np.complex128, np.clongdouble,
    np.timedelta64,
    np.object_,
)

type _CorrelateMode = L["valid", "same", "full"]

type _0D = tuple[()]
type _1D = tuple[int]
type _2D = tuple[int, int]
type _3D = tuple[int, int, int]
type _4D = tuple[int, int, int, int]

type _ArrayMax2D[ScalarT: np.generic] = np.ndarray[_1D | _2D, np.dtype[ScalarT]]

# workaround for mypy and pyright not following the typing spec for overloads
type _ArrayJustND[ScalarT: np.generic] = np.ndarray[tuple[Never, Never, Never, Never], np.dtype[ScalarT]]

type _ToArray0D = Array0D[Any] | complex | str | np.generic
type _ToArray1D = Array1D[Any] | Sequence[complex | np.generic]
type _ToArray2D = Array2D[Any] | Sequence[Sequence[complex | np.generic]]
type _ToArray3D = Array3D[Any] | Sequence[Sequence[Sequence[complex | np.generic]]]
type _ToArray4D = Array4D[Any] | Sequence[Sequence[Sequence[Sequence[complex | np.generic]]]]

type _TensorAxes = int | tuple[_ShapeLike, _ShapeLike]

type _Int_co = np.integer | np.bool
type _Float_co = np.floating | _Int_co
type _Number_co = np.number | np.bool
type _TD64_co = np.timedelta64 | _Int_co
type _ScalarNotObject = np.number | np.bool | np.character | np.datetime64 | np.timedelta64

type _ArrayLike1D[ScalarT: np.generic] = _SupportsArray[np.dtype[ScalarT]] | Sequence[ScalarT]
type _ArrayLike1DBool_co = _SupportsArray[np.dtype[np.bool]] | Sequence[py_bool | np.bool]
type _ArrayLike1DInt_co = _SupportsArray[np.dtype[_Int_co]] | Sequence[int | _Int_co]
type _ArrayLike1DFloat_co = _SupportsArray[np.dtype[_Float_co]] | Sequence[float | _Float_co]
type _ArrayLike1DNumber_co = _SupportsArray[np.dtype[_Number_co]] | Sequence[complex | _Number_co]
type _ArrayLike1DTD64_co = _ArrayLike1D[_TD64_co]
type _ArrayLike1DObject_co = _ArrayLike1D[np.object_]

type _Func1D[ScalarT: np.generic, ReturnT] = Callable[[Array1D[ScalarT]], ReturnT]
type _Func2D[ScalarT: np.generic, ReturnT] = Callable[[Array2D[ScalarT], Array2D[ScalarT]], ReturnT]
type _Func3D[ScalarT: np.generic, ReturnT] = Callable[[Array3D[ScalarT], Array3D[ScalarT], Array3D[ScalarT]], ReturnT]

type _DTypeLikeInt = type[int] | _IntPCodes
type _DTypeLikeFloat64 = type[float] | _Float64Codes
type _DTypeLikeComplex128 = type[complex] | _Complex128Codes

###

# keep in sync with `ones_like` and empty_like in `core/multiarray.pyi`
@overload  # known array, subok=True (default)
def zeros_like[ArrayT: NDArray[_ScalarNotObject]](
    a: ArrayT,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: L[True] = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> ArrayT: ...
@overload  # known array, subok=False
def zeros_like[ShapeT: _Shape, DTypeT: np.dtype[_ScalarNotObject]](
    a: np.ndarray[ShapeT, DTypeT],
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: L[False],
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, DTypeT]: ...
@overload  # known array, object_
def zeros_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT, np.dtype[np.object_]],
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: py_bool = True,
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[int]]]: ...
@overload  # known array, dtype=<known>
def zeros_like[ShapeT: _Shape, ScalarT: np.generic](
    a: np.ndarray[ShapeT],
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array, dtype=<unknown>
def zeros_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT],
    dtype: DTypeLike,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[Any]]: ...
@overload  # known array-like, shape=<known>
def zeros_like[ShapeT: _Shape, ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array-like, object_, shape=<known>
def zeros_like[ShapeT: _Shape](
    a: _ArrayLike[np.object_],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[int]]]: ...
@overload  # known array-like
def zeros_like[ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # known array-like, object_
def zeros_like(
    a: _ArrayLike[np.object_],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[np.object_[int]]: ...
@overload  # unknown, dtype=<known>
def zeros_like[ScalarT: np.generic](
    a: object,
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # fallback
def zeros_like(
    a: object,
    dtype: DTypeLike | None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[Any]: ...

# keep in sync with empty and zeros (`_core/multiarray.pyi`)
@overload  # 1d, float64 default
def ones(
    shape: SupportsIndex,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> Array1D[np.float64]: ...
@overload  # 1d, specific dtype
def ones[DTypeT: np.dtype](
    shape: SupportsIndex,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> ndarray[tuple[int], DTypeT]: ...
@overload  # 1d, specific scalar type
def ones[ScalarT: np.generic](
    shape: SupportsIndex,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> Array1D[ScalarT]: ...
@overload  # 1d, bool
def ones(
    shape: SupportsIndex,
    dtype: _DTypeLikeBool,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> Array1D[np.bool]: ...
@overload  # 1d, unknown dtype
def ones(
    shape: SupportsIndex,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> Array1D[Incomplete]: ...
@overload  # known shape, float64 default
def ones[ShapeT: (_0D, _1D, _2D, _3D, _4D)](
    shape: ShapeT,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, float64]: ...
@overload  # known shape, specific dtype
def ones[ShapeT: (_0D, _1D, _2D, _3D, _4D), DTypeT: np.dtype](
    shape: ShapeT,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> ndarray[ShapeT, DTypeT]: ...
@overload  # known shape, specific scalar type
def ones[ShapeT: (_0D, _1D, _2D, _3D, _4D), ScalarT: np.generic](
    shape: ShapeT,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, ScalarT]: ...
@overload  # known shape, bool
def ones[ShapeT: (_0D, _1D, _2D, _3D, _4D)](
    shape: ShapeT,
    dtype: _DTypeLikeBool,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, np.bool]: ...
@overload  # known shape, unknown dtype
def ones[ShapeT: (_0D, _1D, _2D, _3D, _4D)](
    shape: ShapeT,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, Incomplete]: ...
@overload  # unknown shape, float64 default
def ones(
    shape: _ShapeLike,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[float64]: ...
@overload  # unknown shape, specific dtype
def ones[DTypeT: np.dtype](
    shape: _ShapeLike,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> ndarray[_AnyShape, DTypeT]: ...
@overload  # unknown shape, specific scalar type
def ones[ScalarT: np.generic](
    shape: _ShapeLike,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[ScalarT]: ...
@overload  # unknown shape, bool
def ones(
    shape: _ShapeLike,
    dtype: _DTypeLikeBool,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[np.bool]: ...
@overload  # unknown shape, unknown dtype
def ones(
    shape: _ShapeLike,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[Incomplete]: ...

# keep in sync with `zeros_like`
@overload  # known array, subok=True (default)
def ones_like[ArrayT: NDArray[_ScalarNotObject]](
    a: ArrayT,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: L[True] = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> ArrayT: ...
@overload  # known array, subok=False
def ones_like[ShapeT: _Shape, DTypeT: np.dtype[_ScalarNotObject]](
    a: np.ndarray[ShapeT, DTypeT],
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: L[False],
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, DTypeT]: ...
@overload  # known array, object_
def ones_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT, np.dtype[np.object_]],
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: py_bool = True,
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[int]]]: ...
@overload  # known array, dtype=<known>
def ones_like[ShapeT: _Shape, ScalarT: np.generic](
    a: np.ndarray[ShapeT],
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array, dtype=<unknown>
def ones_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT],
    dtype: DTypeLike,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[Any]]: ...
@overload  # known array-like, shape=<known>
def ones_like[ShapeT: _Shape, ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array-like, object_, shape=<known>
def ones_like[ShapeT: _Shape](
    a: _ArrayLike[np.object_],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[int]]]: ...
@overload  # known array-like
def ones_like[ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # known array-like, object_
def ones_like(
    a: _ArrayLike[np.object_],
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[np.object_[int]]: ...
@overload  # unknown, dtype=<known>
def ones_like[ScalarT: np.generic](
    a: object,
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # fallback
def ones_like(
    a: object,
    dtype: DTypeLike | None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[Any]: ...

# TODO: Add overloads for bool, int, float, complex, str, bytes, and memoryview
# 1-D shape
@overload
def full[ScalarT: np.generic](
    shape: SupportsIndex,
    fill_value: ScalarT,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[tuple[int], ScalarT]: ...
@overload
def full[DTypeT: np.dtype](
    shape: SupportsIndex,
    fill_value: Any,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> np.ndarray[tuple[int], DTypeT]: ...
@overload
def full[ScalarT: np.generic](
    shape: SupportsIndex,
    fill_value: Any,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[tuple[int], ScalarT]: ...
@overload
def full(
    shape: SupportsIndex,
    fill_value: Any,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[tuple[int], Any]: ...
# known shape
@overload
def full[ShapeT: _Shape, ScalarT: np.generic](
    shape: ShapeT,
    fill_value: ScalarT,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, ScalarT]: ...
@overload
def full[ShapeT: _Shape, DTypeT: np.dtype](
    shape: ShapeT,
    fill_value: Any,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> np.ndarray[ShapeT, DTypeT]: ...
@overload
def full[ShapeT: _Shape, ScalarT: np.generic](
    shape: ShapeT,
    fill_value: Any,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, ScalarT]: ...
@overload
def full[ShapeT: _Shape](
    shape: ShapeT,
    fill_value: Any,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> _Array[ShapeT, Any]: ...
# unknown shape
@overload
def full[ScalarT: np.generic](
    shape: _ShapeLike,
    fill_value: ScalarT,
    dtype: None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[ScalarT]: ...
@overload
def full[DTypeT: np.dtype](
    shape: _ShapeLike,
    fill_value: Any,
    dtype: DTypeT | _SupportsDType[DTypeT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> np.ndarray[Any, DTypeT]: ...
@overload
def full[ScalarT: np.generic](
    shape: _ShapeLike,
    fill_value: Any,
    dtype: type[ScalarT],
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[ScalarT]: ...
@overload
def full(
    shape: _ShapeLike,
    fill_value: Any,
    dtype: DTypeLike | None = None,
    order: _OrderCF = "C",
    *,
    device: L["cpu"] | None = None,
    like: _SupportsArrayFunc | None = None,
) -> NDArray[Any]: ...

# keep in sync with `zeros_like` and `ones_like` (modulo `fill_value`)
@overload  # known array, subok=True (default)
def full_like[ArrayT: NDArray[_ScalarNotObject]](
    a: ArrayT,
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: L[True] = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> ArrayT: ...
@overload  # known array, subok=False
def full_like[ShapeT: _Shape, DTypeT: np.dtype](
    a: np.ndarray[ShapeT, DTypeT],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: L[False],
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, DTypeT]: ...
@overload  # known array, object_
def full_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT, np.dtype[np.object_]],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    *,
    subok: py_bool = True,
    shape: None = None,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[Any]]]: ...
@overload  # known array, dtype=<known>
def full_like[ShapeT: _Shape, ScalarT: np.generic](
    a: np.ndarray[ShapeT],
    fill_value: object,
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array, dtype=<unknown>
def full_like[ShapeT: _Shape](
    a: np.ndarray[ShapeT],
    fill_value: object,
    dtype: DTypeLike,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: None = None,
    *,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[Any]]: ...
@overload  # known array-like, shape=<known>
def full_like[ShapeT: _Shape, ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[ScalarT]]: ...
@overload  # known array-like, object_, shape=<known>
def full_like[ShapeT: _Shape](
    a: _ArrayLike[np.object_],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    *,
    shape: ShapeT,
    device: L["cpu"] | None = None,
) -> np.ndarray[ShapeT, np.dtype[np.object_[Any]]]: ...
@overload  # known array-like
def full_like[ScalarT: _ScalarNotObject](
    a: _ArrayLike[ScalarT],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # known array-like, object_
def full_like(
    a: _ArrayLike[np.object_],
    fill_value: object,
    dtype: None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[np.object_[Any]]: ...
@overload  # unknown, dtype=<known>
def full_like[ScalarT: np.generic](
    a: object,
    fill_value: object,
    dtype: _DTypeLike[ScalarT],
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[ScalarT]: ...
@overload  # fallback
def full_like(
    a: object,
    fill_value: object,
    dtype: DTypeLike | None = None,
    order: _OrderKACF = "K",
    subok: py_bool = True,
    shape: _ShapeLike | None = None,
    *,
    device: L["cpu"] | None = None,
) -> NDArray[Any]: ...

#
@overload  # Nd, keepdims=True
def count_nonzero[ShapeT: tuple[int, *tuple[int, ...]]](
    a: np.ndarray[ShapeT, Any],
    axis: _ShapeLike | None = None,
    *,
    keepdims: L[True],
) -> np.ndarray[ShapeT, np.dtype[np.intp]]: ...
@overload  # ?d, axis=<given>  (workaround)
def count_nonzero(a: _ArrayJustND[Any], axis: _ShapeLike, *, keepdims: L[False] = False) -> NDArray[np.intp] | Any: ...
@overload  # 0d, keepdims=True
def count_nonzero(a: _ToArray0D, axis: _ShapeLike | None = None, *, keepdims: L[True]) -> np.intp: ...
@overload  # 1d, keepdims=True
def count_nonzero(a: _ToArray1D, axis: _ShapeLike | None = None, *, keepdims: L[True]) -> Array1D[np.intp]: ...
@overload  # 1d, axis=<given>
def count_nonzero(a: _ToArray1D, axis: int | tuple[int], *, keepdims: L[False] = False) -> np.intp: ...
@overload  # 2d, keepdims=True
def count_nonzero(a: _ToArray2D, axis: _ShapeLike | None = None, *, keepdims: L[True]) -> Array2D[np.intp]: ...
@overload  # 2d, axis=<given>
def count_nonzero(a: _ToArray2D, axis: int | tuple[int], *, keepdims: L[False] = False) -> Array1D[np.intp]: ...
@overload  # 3d, keepdims=True
def count_nonzero(a: _ToArray3D, axis: _ShapeLike | None = None, *, keepdims: L[True]) -> Array3D[np.intp]: ...
@overload  # 3d, axis=<given>
def count_nonzero(a: _ToArray3D, axis: int | tuple[int], *, keepdims: L[False] = False) -> Array2D[np.intp]: ...
@overload  # 4d, keepdims=True
def count_nonzero(a: _ToArray4D, axis: _ShapeLike | None = None, *, keepdims: L[True]) -> Array4D[np.intp]: ...
@overload  # 4d, axis=<given>
def count_nonzero(a: _ToArray4D, axis: int | tuple[int], *, keepdims: L[False] = False) -> Array3D[np.intp]: ...
@overload  # Nd, axis=None  (default)
def count_nonzero(a: ArrayLike, axis: None = None, *, keepdims: L[False] = False) -> np.intp: ...
@overload  # Nd, keepdims=True  (fallback)
def count_nonzero(a: _NestedSequence[ArrayLike], axis: _ShapeLike | None = None, *, keepdims: L[True]) -> NDArray[np.intp]: ...
@overload  # Nd, axis=<given>  (fallback)
def count_nonzero(a: ArrayLike, axis: _ShapeLike, *, keepdims: L[False] = False) -> NDArray[np.intp] | Any: ...
@overload  # fallback
def count_nonzero(a: ArrayLike, axis: _ShapeLike | None = None, *, keepdims: py_bool = False) -> Any: ...

#
@deprecated("numpy.isfortran is deprecated. Use a.flags.fnc instead.")
def isfortran(a: ndarray | generic) -> py_bool: ...

#
def argwhere(a: ArrayLike) -> Array2D[np.intp]: ...
def flatnonzero(a: ArrayLike) -> Array1D[np.intp]: ...

# NOTE: we ignore UP047 because inlining `_AnyScalarT` would result in a lot of code duplication

# keep in sync with `convolve` and `ma.core.correlate`
@overload
def correlate(  # noqa: UP047
    a: _ArrayLike1D[_AnyNumberT], v: _ArrayLike1D[_AnyNumberT], mode: _CorrelateMode = "valid"
) -> Array1D[_AnyNumberT]: ...
@overload
def correlate(a: _ArrayLike1DBool_co, v: _ArrayLike1DBool_co, mode: _CorrelateMode = "valid") -> Array1D[np.bool]: ...
@overload
def correlate(a: _ArrayLike1DInt_co, v: _ArrayLike1DInt_co, mode: _CorrelateMode = "valid") -> Array1D[np.int_ | Any]: ...
@overload
def correlate(a: _ArrayLike1DFloat_co, v: _ArrayLike1DFloat_co, mode: _CorrelateMode = "valid") -> Array1D[np.float64 | Any]: ...
@overload
def correlate(
    a: _ArrayLike1DNumber_co, v: _ArrayLike1DNumber_co, mode: _CorrelateMode = "valid"
) -> Array1D[np.complex128 | Any]: ...
@overload
def correlate(
    a: _ArrayLike1DTD64_co, v: _ArrayLike1DTD64_co, mode: _CorrelateMode = "valid"
) -> Array1D[np.timedelta64 | Any]: ...

# keep in sync with `correlate`
@overload
def convolve(  # noqa: UP047
    a: _ArrayLike1D[_AnyNumberT], v: _ArrayLike1D[_AnyNumberT], mode: _CorrelateMode = "valid"
) -> Array1D[_AnyNumberT]: ...
@overload
def convolve(a: _ArrayLike1DBool_co, v: _ArrayLike1DBool_co, mode: _CorrelateMode = "valid") -> Array1D[np.bool]: ...
@overload
def convolve(a: _ArrayLike1DInt_co, v: _ArrayLike1DInt_co, mode: _CorrelateMode = "valid") -> Array1D[np.int_ | Any]: ...
@overload
def convolve(a: _ArrayLike1DFloat_co, v: _ArrayLike1DFloat_co, mode: _CorrelateMode = "valid") -> Array1D[np.float64 | Any]: ...
@overload
def convolve(
    a: _ArrayLike1DNumber_co, v: _ArrayLike1DNumber_co, mode: _CorrelateMode = "valid"
) -> Array1D[np.complex128 | Any]: ...
@overload
def convolve(
    a: _ArrayLike1DTD64_co, v: _ArrayLike1DTD64_co, mode: _CorrelateMode = "valid"
) -> Array1D[np.timedelta64 | Any]: ...

# keep roughly in sync with `convolve` and `correlate`, but for 2-D output and an additional `out` overload,
# and also keep in sync with `ma.core.outer` (minus `out`)
@overload
def outer(  # noqa: UP047
    a: _ArrayLike[_AnyNumberT], b: _ArrayLike[_AnyNumberT], out: None = None
) -> Array2D[_AnyNumberT]: ...
@overload
def outer(a: _ArrayLikeBool_co, b: _ArrayLikeBool_co, out: None = None) -> Array2D[np.bool]: ...
@overload
def outer(a: _ArrayLikeInt_co, b: _ArrayLikeInt_co, out: None = None) -> Array2D[np.int_ | Any]: ...
@overload
def outer(a: _ArrayLikeFloat_co, b: _ArrayLikeFloat_co, out: None = None) -> Array2D[np.float64 | Any]: ...
@overload
def outer(a: _ArrayLikeComplex_co, b: _ArrayLikeComplex_co, out: None = None) -> Array2D[np.complex128 | Any]: ...
@overload
def outer(a: _ArrayLikeTD64_co, b: _ArrayLikeTD64_co, out: None = None) -> Array2D[np.timedelta64 | Any]: ...
@overload
def outer[ArrayT: np.ndarray](a: _ArrayLikeNumber_co | _ArrayLikeTD64_co, b: _ArrayLikeNumber_co | _ArrayLikeTD64_co, out: ArrayT) -> ArrayT: ...

# keep in sync with numpy.linalg._linalg.tensordot (ignoring `/, *`)
@overload  # ?d ~T, Nd ~T (workaround)
def tensordot(a: _ArrayJustND[_AnyNumberT], b: _ArrayLike[_AnyNumberT], axes: _TensorAxes = 2) -> NDArray[_AnyNumberT]: ...  # noqa: UP047
@overload  # Nd ~T, ?d ~T (workaround)
def tensordot(a: _ArrayLike[_AnyNumberT], b: _ArrayJustND[_AnyNumberT], axes: _TensorAxes = 2) -> NDArray[_AnyNumberT]: ...  # noqa: UP047
@overload  # ?d +bool, Nd +bool (workaround)
def tensordot(a: _ArrayJustND[np.bool], b: _ArrayLikeBool_co, axes: _TensorAxes = 2) -> NDArray[np.bool]: ...
@overload  # Nd +bool, ?d +bool (workaround)
def tensordot(a: _ArrayLikeBool_co, b: _ArrayJustND[np.bool], axes: _TensorAxes = 2) -> NDArray[np.bool]: ...
@overload  # ?d +i64, Nd +i64 (workaround)
def tensordot(a: _ArrayJustND[_Int_co], b: _ArrayLikeInt_co, axes: _TensorAxes = 2) -> NDArray[np.int_ | Any]: ...
@overload  # Nd +i64, ?d +i64 (workaround)
def tensordot(a: _ArrayLikeInt_co, b: _ArrayJustND[_Int_co], axes: _TensorAxes = 2) -> NDArray[np.int_ | Any]: ...
@overload  # ?d +f64, Nd +f64 (workaround)
def tensordot(a: _ArrayJustND[_Float_co], b: _ArrayLikeFloat_co, axes: _TensorAxes = 2) -> NDArray[np.float64 | Any]: ...
@overload  # Nd +f64, ?d +f64 (workaround)
def tensordot(a: _ArrayLikeFloat_co, b: _ArrayJustND[_Float_co], axes: _TensorAxes = 2) -> NDArray[np.float64 | Any]: ...
@overload  # ?d, Nd (fallback) (workaround)
def tensordot(a: _ArrayJustND[_Number_co], b: _ArrayLikeComplex_co, axes: _TensorAxes = 2) -> NDArray[np.complex128 | Any]: ...
@overload  # Nd, ?d (fallback) (workaround)
def tensordot(a: _ArrayLikeComplex_co, b: _ArrayJustND[_Number_co], axes: _TensorAxes = 2) -> NDArray[np.complex128 | Any]: ...
@overload  # 1d ~T, 1d ~T, axes=0
def tensordot(a: Array1D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[0]) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 1d ~T, 1d ~T, axes=1
def tensordot(a: Array1D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[1]) -> Array0D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 1d ~T, 2d ~T, axes=0
def tensordot(a: Array1D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[0]) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 1d ~T, 2d ~T, axes=1
def tensordot(a: Array1D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[1]) -> Array1D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 1d ~T, 3d ~T, axes=0
def tensordot(a: Array1D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[0]) -> Array4D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 1d ~T, 3d ~T, axes=1
def tensordot(a: Array1D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[1]) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 1d ~T, axes=0
def tensordot(a: Array2D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[0]) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 1d ~T, axes=1
def tensordot(a: Array2D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[1]) -> Array1D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 2d ~T, axes=0
def tensordot(a: Array2D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[0]) -> Array4D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 2d ~T, axes=1
def tensordot(a: Array2D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[1]) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 2d ~T, axes=2
def tensordot(a: Array2D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[2] = 2) -> Array0D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 3d ~T, axes=1
def tensordot(a: Array2D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[1]) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 3d ~T, axes=2
def tensordot(a: Array2D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[2] = 2) -> Array1D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 2d ~T, 4d ~T, axes=2
def tensordot(a: Array2D[_AnyNumberT], b: Array4D[_AnyNumberT], axes: L[2] = 2) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 1d ~T, axes=0
def tensordot(a: Array3D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[0]) -> Array4D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 1d ~T, axes=1
def tensordot(a: Array3D[_AnyNumberT], b: Array1D[_AnyNumberT], axes: L[1]) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 2d ~T, axes=1
def tensordot(a: Array3D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[1]) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 2d ~T, axes=2
def tensordot(a: Array3D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[2] = 2) -> Array1D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 3d ~T, axes=1
def tensordot(a: Array3D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[1]) -> Array4D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 3d ~T, axes=2
def tensordot(a: Array3D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[2] = 2) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 3d ~T, 4d ~T, axes=2
def tensordot(a: Array3D[_AnyNumberT], b: Array4D[_AnyNumberT], axes: L[2] = 2) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 4d ~T, 2d ~T, axes=2
def tensordot(a: Array4D[_AnyNumberT], b: Array2D[_AnyNumberT], axes: L[2] = 2) -> Array2D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 4d ~T, 3d ~T, axes=2
def tensordot(a: Array4D[_AnyNumberT], b: Array3D[_AnyNumberT], axes: L[2] = 2) -> Array3D[_AnyNumberT]: ...  # noqa: UP047
@overload  # 4d ~T, 4d ~T, axes=2
def tensordot(a: Array4D[_AnyNumberT], b: Array4D[_AnyNumberT], axes: L[2] = 2) -> Array4D[_AnyNumberT]: ...  # noqa: UP047
@overload  # ?d ~T, ?d ~T
def tensordot(a: _ArrayLike[_AnyNumberT], b: _ArrayLike[_AnyNumberT], axes: _TensorAxes = 2) -> NDArray[_AnyNumberT]: ...  # noqa: UP047
@overload
def tensordot(a: _ArrayLikeBool_co, b: _ArrayLikeBool_co, axes: _TensorAxes = 2) -> NDArray[np.bool]: ...
@overload
def tensordot(a: _ArrayLikeInt_co, b: _ArrayLikeInt_co, axes: _TensorAxes = 2) -> NDArray[np.int_ | Any]: ...
@overload
def tensordot(a: _ArrayLikeFloat_co, b: _ArrayLikeFloat_co, axes: _TensorAxes = 2) -> NDArray[np.float64 | Any]: ...
@overload
def tensordot(a: _ArrayLikeComplex_co, b: _ArrayLikeComplex_co, axes: _TensorAxes = 2) -> NDArray[np.complex128 | Any]: ...

#
@overload  # ?d T, ?d T  (workaround)
def cross(  # noqa: UP047
    a: _ArrayJustND[_AnyNumberT],
    b: _ArrayLike[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[_AnyNumberT]: ...
@overload  # ?d T, ?d T  (workaround)
def cross(  # noqa: UP047
    a: _ArrayLike[_AnyNumberT],
    b: _ArrayJustND[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[_AnyNumberT]: ...
@overload  # 1d T, 1d T
def cross(  # noqa: UP047
    a: Array1D[_AnyNumberT],
    b: Array1D[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> Array1D[_AnyNumberT]: ...
@overload  # 1d T, 2d T
def cross(  # noqa: UP047
    a: Array1D[_AnyNumberT],
    b: Array2D[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> Array2D[_AnyNumberT]: ...
@overload  # 2d T, <=2d T
def cross(  # noqa: UP047
    a: Array2D[_AnyNumberT],
    b: _ArrayMax2D[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> Array2D[_AnyNumberT]: ...
@overload  # <=2d T, 3d T
def cross(  # noqa: UP047
    a: _ArrayMax2D[_AnyNumberT],
    b: Array3D[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> Array3D[_AnyNumberT]: ...
@overload  # 3d T, <=3d T
def cross(  # noqa: UP047
    a: Array3D[_AnyNumberT],
    b: np.ndarray[tuple[int] | tuple[int, int] | tuple[int, int, int], np.dtype[_AnyNumberT]],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> Array3D[_AnyNumberT]: ...
@overload  # ?d T, ?d T
def cross(  # noqa: UP047
    a: _ArrayLike[_AnyNumberT],
    b: _ArrayLike[_AnyNumberT],
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[_AnyNumberT]: ...
@overload  # ?d +int, ?d +int
def cross(
    a: _ArrayLikeInt_co,
    b: _ArrayLikeInt_co,
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[np.int_ | Any]: ...
@overload  # ?d +f64, ?d +f64
def cross(
    a: _ArrayLikeFloat_co,
    b: _ArrayLikeFloat_co,
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[np.float64 | Any]: ...
@overload  # ?d +c128, ?d +c128
def cross(
    a: _ArrayLikeComplex_co,
    b: _ArrayLikeComplex_co,
    axisa: int = -1,
    axisb: int = -1,
    axisc: int = -1,
    axis: int | None = None,
) -> NDArray[np.complex128 | Any]: ...

#
@overload
def roll[ArrayT: np.ndarray](a: ArrayT, shift: _ShapeLike, axis: _ShapeLike | None = None) -> ArrayT: ...
@overload
def roll[ScalarT: np.generic](a: _ArrayLike[ScalarT], shift: _ShapeLike, axis: _ShapeLike | None = None) -> NDArray[ScalarT]: ...
@overload
def roll(a: ArrayLike, shift: _ShapeLike, axis: _ShapeLike | None = None) -> NDArray[Any]: ...

#
def rollaxis[ArrayT: np.ndarray](a: ArrayT, axis: int, start: int = 0) -> ArrayT: ...
def moveaxis[ArrayT: np.ndarray](a: ArrayT, source: _ShapeLike, destination: _ShapeLike) -> ArrayT: ...
def normalize_axis_tuple(
    axis: int | Iterable[int],
    ndim: int,
    argname: str | None = None,
    allow_duplicate: py_bool | None = False,
) -> tuple[int, ...]: ...

#
@overload  # 0d, dtype=int (default), sparse=False (default)
def indices(dimensions: tuple[()], dtype: type[int] = int, sparse: L[False] = False) -> Array1D[np.intp]: ...
@overload  # 0d, dtype=<irrelevant>, sparse=True
def indices(dimensions: tuple[()], dtype: DTypeLike | None = int, *, sparse: L[True]) -> tuple[()]: ...
@overload  # 0d, dtype=<known>, sparse=False (default)
def indices[ScalarT: np.generic](dimensions: tuple[()], dtype: _DTypeLike[ScalarT], sparse: L[False] = False) -> Array1D[ScalarT]: ...
@overload  # 0d, dtype=<unknown>, sparse=False (default)
def indices(dimensions: tuple[()], dtype: DTypeLike, sparse: L[False] = False) -> Array1D[Any]: ...
@overload  # 1d, dtype=int (default), sparse=False (default)
def indices(dimensions: tuple[int], dtype: type[int] = int, sparse: L[False] = False) -> Array2D[np.intp]: ...
@overload  # 1d, dtype=int (default), sparse=True
def indices(dimensions: tuple[int], dtype: type[int] = int, *, sparse: L[True]) -> tuple[Array1D[np.intp]]: ...
@overload  # 1d, dtype=<known>, sparse=False (default)
def indices[ScalarT: np.generic](dimensions: tuple[int], dtype: _DTypeLike[ScalarT], sparse: L[False] = False) -> Array2D[ScalarT]: ...
@overload  # 1d, dtype=<known>, sparse=True
def indices[ScalarT: np.generic](dimensions: tuple[int], dtype: _DTypeLike[ScalarT], sparse: L[True]) -> tuple[Array1D[ScalarT]]: ...
@overload  # 1d, dtype=<unknown>, sparse=False (default)
def indices(dimensions: tuple[int], dtype: DTypeLike, sparse: L[False] = False) -> Array2D[Any]: ...
@overload  # 1d, dtype=<unknown>, sparse=True
def indices(dimensions: tuple[int], dtype: DTypeLike, sparse: L[True]) -> tuple[Array1D[Any]]: ...
@overload  # 2d, dtype=int (default), sparse=False (default)
def indices(dimensions: tuple[int, int], dtype: type[int] = int, sparse: L[False] = False) -> Array3D[np.intp]: ...
@overload  # 2d, dtype=int (default), sparse=True
def indices(
    dimensions: tuple[int, int], dtype: type[int] = int, *, sparse: L[True]
) -> tuple[Array2D[np.intp], Array2D[np.intp]]: ...
@overload  # 2d, dtype=<known>, sparse=False (default)
def indices[ScalarT: np.generic](dimensions: tuple[int, int], dtype: _DTypeLike[ScalarT], sparse: L[False] = False) -> Array3D[ScalarT]: ...
@overload  # 2d, dtype=<known>, sparse=True
def indices[ScalarT: np.generic](
    dimensions: tuple[int, int], dtype: _DTypeLike[ScalarT], sparse: L[True]
) -> tuple[Array2D[ScalarT], Array2D[ScalarT]]: ...
@overload  # 2d, dtype=<unknown>, sparse=False (default)
def indices(dimensions: tuple[int, int], dtype: DTypeLike, sparse: L[False] = False) -> Array3D[Any]: ...
@overload  # 2d, dtype=<unknown>, sparse=True
def indices(dimensions: tuple[int, int], dtype: DTypeLike, sparse: L[True]) -> tuple[Array2D[Any], Array2D[Any]]: ...
@overload  # ?d, dtype=int (default), sparse=False (default)
def indices(dimensions: Sequence[int], dtype: type[int] = int, sparse: L[False] = False) -> NDArray[np.intp]: ...
@overload  # ?d, dtype=int (default), sparse=True
def indices(dimensions: Sequence[int], dtype: type[int] = int, *, sparse: L[True]) -> tuple[NDArray[np.intp], ...]: ...
@overload  # ?d, dtype=<known>, sparse=False (default)
def indices[ScalarT: np.generic](dimensions: Sequence[int], dtype: _DTypeLike[ScalarT], sparse: L[False] = False) -> NDArray[ScalarT]: ...
@overload  # ?d, dtype=<known>, sparse=True
def indices[ScalarT: np.generic](dimensions: Sequence[int], dtype: _DTypeLike[ScalarT], sparse: L[True]) -> tuple[NDArray[ScalarT], ...]: ...
@overload  # ?d, dtype=<unknown>, sparse=False (default)
def indices(dimensions: Sequence[int], dtype: DTypeLike, sparse: L[False] = False) -> ndarray: ...
@overload  # ?d, dtype=<unknown>, sparse=True
def indices(dimensions: Sequence[int], dtype: DTypeLike, sparse: L[True]) -> tuple[ndarray, ...]: ...

#
@overload  # (1d T) -> ?, 1d, dtype=<known>
def fromfunction[ScalarT: np.generic, ReturnT](
    function: _Func1D[ScalarT, ReturnT],
    shape: tuple[int],
    *,
    dtype: _DTypeLike[ScalarT],
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (1d int_) -> ?, 1d, dtype=int
def fromfunction[ReturnT](
    function: _Func1D[np.int_, ReturnT],
    shape: tuple[int],
    *,
    dtype: _DTypeLikeInt,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (1d f64) -> ?, 1d, dtype=float (default)
def fromfunction[ReturnT](
    function: _Func1D[np.float64, ReturnT],
    shape: tuple[int],
    *,
    dtype: _DTypeLikeFloat64 | None = float,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (1d ?) -> ?, 1d, dtype=<unknown>
def fromfunction[ReturnT](
    function: _Func1D[Any, ReturnT],
    shape: tuple[int],
    *,
    dtype: DTypeLike,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (2d T, 2d T) -> ?, 2d, dtype=<known>
def fromfunction[ScalarT: np.generic, ReturnT](
    function: _Func2D[ScalarT, ReturnT],
    shape: tuple[int, int],
    *,
    dtype: _DTypeLike[ScalarT],
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (2d int_, 2d int_) -> ?, 2d, dtype=int
def fromfunction[ReturnT](
    function: _Func2D[np.int_, ReturnT],
    shape: tuple[int, int],
    *,
    dtype: _DTypeLikeInt,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (2d f64, 2d f64) -> ?, 2d, dtype=float (default)
def fromfunction[ReturnT](
    function: _Func2D[np.float64, ReturnT],
    shape: tuple[int, int],
    *,
    dtype: _DTypeLikeFloat64 | None = float,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (2d ?, 2d ?) -> ?, 2d, dtype=<unknown>
def fromfunction[ReturnT](
    function: _Func2D[Any, ReturnT],
    shape: tuple[int, int],
    *,
    dtype: DTypeLike,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (3d T, 3d T, 3d T) -> ?, 3d, dtype=<known>
def fromfunction[ScalarT: np.generic, ReturnT](
    function: _Func3D[ScalarT, ReturnT],
    shape: tuple[int, int, int],
    *,
    dtype: _DTypeLike[ScalarT],
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (3d int_, 3d int_, 3d int_) -> ?, 3d, dtype=int
def fromfunction[ReturnT](
    function: _Func3D[np.int_, ReturnT],
    shape: tuple[int, int, int],
    *,
    dtype: _DTypeLikeInt,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (3d f64, 3d f64, 3d f64) -> ?, 3d, dtype=float (default)
def fromfunction[ReturnT](
    function: _Func3D[np.float64, ReturnT],
    shape: tuple[int, int, int],
    *,
    dtype: _DTypeLikeFloat64 | None = float,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (3d ?, 3d ?, 3d ?) -> ?, 3d, dtype=<unknown>
def fromfunction[ReturnT](
    function: _Func3D[Any, ReturnT],
    shape: tuple[int, int, int],
    *,
    dtype: DTypeLike,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...
@overload  # (*?d) -> ?, ?d  (fallback)
def fromfunction[ReturnT](
    function: Callable[..., ReturnT],
    shape: tuple[int, int, int, *tuple[int, ...]] | list[int],
    *,
    dtype: DTypeLike | None = float,
    like: _SupportsArrayFunc | None = None,
    **kwargs: object,
) -> ReturnT: ...

# NOTE: simplifying `int | float | complex` to `complex` causes mypy issues
def isscalar(element: object) -> TypeIs[generic | int | float | complex | str | bytes | memoryview | numbers.Number]: ...

#
def binary_repr(num: SupportsIndex, width: int | None = None) -> str: ...
def base_repr(number: SupportsAbs[float], base: float = 2, padding: SupportsIndex | None = 0) -> str: ...

#
@overload  # dtype: None (default)
def identity(n: int, dtype: None = None, *, like: _SupportsArrayFunc | None = None) -> Array2D[np.float64]: ...
@overload  # dtype: known scalar type
def identity[ScalarT: np.generic](n: int, dtype: _DTypeLike[ScalarT], *, like: _SupportsArrayFunc | None = None) -> Array2D[ScalarT]: ...
@overload  # dtype: like bool
def identity(n: int, dtype: _DTypeLikeBool, *, like: _SupportsArrayFunc | None = None) -> Array2D[np.bool]: ...
@overload  # dtype: like int_
def identity(n: int, dtype: _DTypeLikeInt, *, like: _SupportsArrayFunc | None = None) -> Array2D[np.int_ | Any]: ...
@overload  # dtype: like float64
def identity(n: int, dtype: _DTypeLikeFloat64, *, like: _SupportsArrayFunc | None = None) -> Array2D[np.float64 | Any]: ...
@overload  # dtype: like complex128
def identity(n: int, dtype: _DTypeLikeComplex128, *, like: _SupportsArrayFunc | None = None) -> Array2D[np.complex128 | Any]: ...
@overload  # dtype: unknown
def identity(n: int, dtype: DTypeLike, *, like: _SupportsArrayFunc | None = None) -> Array2D[Incomplete]: ...

#
def allclose(
    a: ArrayLike,
    b: ArrayLike,
    rtol: ArrayLike = 1e-5,
    atol: ArrayLike = 1e-8,
    equal_nan: py_bool = False,
) -> py_bool: ...

#
@overload  # scalar, scalar
def isclose(
    a: _NumberLike_co,
    b: _NumberLike_co,
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.bool: ...
@overload  # known shape, same shape or scalar
def isclose[ShapeT: _Shape](
    a: np.ndarray[ShapeT],
    b: np.ndarray[ShapeT] | _NumberLike_co,
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[ShapeT, np.dtype[np.bool]]: ...
@overload  # same shape or scalar, known shape
def isclose[ShapeT: _Shape](
    a: np.ndarray[ShapeT] | _NumberLike_co,
    b: np.ndarray[ShapeT],
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[ShapeT, np.dtype[np.bool]]: ...
@overload  # 1d sequence, <=1d array-like
def isclose(
    a: Sequence[_NumberLike_co],
    b: Sequence[_NumberLike_co] | _NumberLike_co | np.ndarray[tuple[int]],
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[tuple[int], np.dtype[np.bool]]: ...
@overload  # <=1d array-like, 1d sequence
def isclose(
    a: Sequence[_NumberLike_co] | _NumberLike_co | np.ndarray[tuple[int]],
    b: Sequence[_NumberLike_co],
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[tuple[int], np.dtype[np.bool]]: ...
@overload  # 2d sequence, <=2d array-like
def isclose(
    a: Sequence[Sequence[_NumberLike_co]],
    b: Sequence[Sequence[_NumberLike_co]] | Sequence[_NumberLike_co] | _NumberLike_co | np.ndarray[tuple[int] | tuple[int, int]],
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[tuple[int, int], np.dtype[np.bool]]: ...
@overload  # <=2d array-like, 2d sequence
def isclose(
    b: Sequence[Sequence[_NumberLike_co]] | Sequence[_NumberLike_co] | _NumberLike_co | np.ndarray[tuple[int] | tuple[int, int]],
    a: Sequence[Sequence[_NumberLike_co]],
    rtol: _ScalarLike_co = 1e-5,
    atol: _ScalarLike_co = 1e-8,
    equal_nan: py_bool = False,
) -> np.ndarray[tuple[int, int], np.dtype[np.bool]]: ...
@overload  # unknown shape, unknown shape
def isclose(
    a: ArrayLike,
    b: ArrayLike,
    rtol: ArrayLike = 1e-5,
    atol: ArrayLike = 1e-8,
    equal_nan: py_bool = False,
) -> NDArray[np.bool] | Any: ...

#
def array_equal(a1: ArrayLike, a2: ArrayLike, equal_nan: py_bool = False) -> py_bool: ...
def array_equiv(a1: ArrayLike, a2: ArrayLike) -> py_bool: ...

#
@overload
def astype[ShapeT: _Shape, ScalarT: np.generic](
    x: ndarray[ShapeT],
    dtype: _DTypeLike[ScalarT],
    /,
    *,
    copy: py_bool = True,
    device: L["cpu"] | None = None,
) -> ndarray[ShapeT, dtype[ScalarT]]: ...
@overload
def astype[ShapeT: _Shape](
    x: ndarray[ShapeT],
    dtype: DTypeLike | None,
    /,
    *,
    copy: py_bool = True,
    device: L["cpu"] | None = None,
) -> ndarray[ShapeT]: ...
