  module coddity
    use iso_c_binding, only: c_double, c_int, c_int64_t
    implicit none
    contains
      subroutine add_cfloat_arr(A, B, C)
        use iso_c_binding, only: c_float_complex
        complex(c_float_complex), intent(in), dimension(3) :: A, B
        complex(c_float_complex), intent(out), dimension(3) :: C
       C = A + B
      end subroutine add_cfloat_arr
      subroutine add_cdouble_arr(A, B, C)
        use iso_c_binding, only: c_double_complex
        complex(c_double_complex), intent(in), dimension(3) :: A, B
        complex(c_double_complex), intent(out), dimension(3) :: C
        C = A + B
      end subroutine add_cdouble_arr
      subroutine add_clong_double_arr(A, B, C)
        use iso_c_binding, only: c_long_double_complex
        complex(c_long_double_complex), intent(in), dimension(3) :: A, B
        complex(c_long_double_complex), intent(out), dimension(3) :: C
        C = A + B
      end subroutine add_clong_double_arr
      subroutine c_add(a, b, c) bind(c, name="c_add")
        real(c_double), intent(in) :: a, b
        real(c_double), intent(out) :: c
        c = a + b
      end subroutine c_add
      ! gh-9693
      function wat(x, y) result(z) bind(c)
          integer(c_int), intent(in) :: x, y
          integer(c_int) :: z

          z = x + 7
      end function wat
      ! gh-25207
      subroutine c_add_int64(a, b, c) bind(c)
        integer(c_int64_t), intent(in) :: a, b
        integer(c_int64_t), intent(out) :: c
        c = a + b
      end subroutine c_add_int64
      ! gh-25207
      subroutine add_arr(A, B, C)
         integer(c_int64_t), intent(in) :: A(3)
         integer(c_int64_t), intent(in) :: B(3)
         integer(c_int64_t), intent(out) :: C(3)
         integer :: j

         do j = 1, 3
            C(j) = A(j)+B(j)
         end do
      end subroutine
      subroutine add_int8_arr(A, B, C)
         use iso_c_binding, only: c_int8_t
         implicit none
         integer(c_int8_t), intent(in) :: A(3)
         integer(c_int8_t), intent(in) :: B(3)
         integer(c_int8_t), intent(out) :: C(3)
         integer :: j

         do j = 1, 3
            C(j) = A(j)+B(j)
         end do
      end subroutine add_int8_arr
      subroutine add_clong_arr(A, B, C)
        use iso_c_binding, only: c_long
        implicit none
        integer(c_long), intent(in), dimension(3) :: A, B
        integer(c_long), intent(out), dimension(3) :: C
        C = A + B
      end subroutine add_clong_arr
  end module coddity
