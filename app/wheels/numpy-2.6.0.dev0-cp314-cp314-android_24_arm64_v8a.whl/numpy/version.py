
"""
Module to expose more detailed version info for the installed `numpy`
"""
version = "2.6.0.dev0+git20261106.c60f172"
__version__ = version
full_version = version

git_revision = "c60f172b3330f76d6592362137f34c4a3030a001"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
